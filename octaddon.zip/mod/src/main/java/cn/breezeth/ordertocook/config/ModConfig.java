package cn.breezeth.ordertocook.config;
/** 本体编译期占位，不进入 jar。 */
public class ModConfig {
    public String customCurrencyItem;
    public boolean sdmShopCurrencyCompat;
}
